'use client';
import { useEffect, useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import { Button, Card, Modal, Input, PageHeader, StatusBadge, Empty } from '@/components/ui';
import { useClient } from '@/hooks/useClient';
import api from '@/lib/api';
import Link from 'next/link';
import { Plus, Building2, Pencil, Trash2, ExternalLink } from 'lucide-react';

const blank = { name: '', wabaId: '', phoneNumberId: '', accessToken: '', phone: '', timezone: 'Asia/Kolkata', industry: '' };

export default function ClientsPage() {
  const { clients, setClients, activeClient, selectClient } = useClient();
  const [modal, setModal]   = useState(false);
  const [form,  setForm]    = useState(blank);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [listError, setListError] = useState('');

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const openNew  = ()    => { setForm(blank); setFormError(''); setEditing(null); setModal(true); };
  const openEdit = (c)   => {
    setForm({ name: c.name, wabaId: c.wabaId, phoneNumberId: c.phoneNumberId, accessToken: '', phone: c.phone || '', timezone: c.timezone || '', industry: c.industry || '' });
    setFormError('');
    setEditing(c._id);
    setModal(true);
  };
  const close = () => setModal(false);

  const save = async () => {
    if (!form.name.trim()) { setFormError('Business name is required.'); return; }
    if (!form.wabaId.trim()) { setFormError('WABA ID is required.'); return; }
    if (!form.phoneNumberId.trim()) { setFormError('Phone Number ID is required.'); return; }
    if (!editing && !form.accessToken.trim()) { setFormError('Access token is required.'); return; }
    setFormError('');
    setSaving(true);
    try {
      if (editing) {
        const { data } = await api.patch(`/clients/${editing}`, form);
        setClients(prev => prev.map(c => c._id === editing ? data : c));
      } else {
        const { data } = await api.post('/clients', form);
        setClients(prev => [...prev, data]);
      }
      close();
    } catch (err) {
      const msg = err?.response?.data?.message;
      setFormError(
        err?.response?.status === 409 || /duplicate/i.test(msg || '')
          ? 'A client with this Phone Number ID already exists.'
          : (msg || 'Could not save this client. Please try again.')
      );
    } finally { setSaving(false); }
  };

  const remove = async (id) => {
    if (!confirm('Delete this client? This cannot be undone.')) return;
    setListError('');
    try {
      await api.delete(`/clients/${id}`);
      setClients(prev => prev.filter(c => c._id !== id));
      // If the deleted client was active, clear the stale selection so other pages don't
      // keep querying a clientId that no longer exists
      if (activeClient?._id === id) {
        localStorage.removeItem('wa_active_client');
        window.location.reload();
      }
    } catch {
      setListError('Could not delete this client. It may have related campaigns or contacts.');
    }
  };

  return (
    <AppShell>
      <PageHeader
        title="Clients"
        subtitle="Manage WhatsApp Business accounts"
        action={<Button onClick={openNew}><Plus size={16} />New Client</Button>}
      />

      {listError && (
        <div className="soft-alert border-red-500/25 bg-red-500/10 text-red-700 dark:text-red-300 mb-5">{listError}</div>
      )}

      {clients.length === 0
        ? <Empty icon={Building2} title="No clients yet" description="Add your first WhatsApp Business client to start sending messages." action={<Button onClick={openNew}><Plus size={15}/>New Client</Button>} />
        : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {clients.map(c => (
              <Card key={c._id} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center">
                    <Building2 size={20} className="text-brand" />
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(c)} className="p-1.5 hover:bg-accent rounded-lg transition-colors text-muted-foreground hover:text-accent-foreground"><Pencil size={14} /></button>
                    <button onClick={() => remove(c._id)} className="p-1.5 hover:bg-red-500/10 rounded-lg transition-colors text-muted-foreground hover:text-red-500"><Trash2 size={14} /></button>
                  </div>
                </div>
                <p className="font-semibold">{c.name}</p>
                <p className="text-xs text-[var(--muted-text)] mt-0.5">{c.phone || c.phoneNumberId}</p>
                {c.industry && <p className="text-xs text-[var(--muted-text)]">{c.industry}</p>}
                <div className="mt-3 flex items-center justify-between">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${c.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                    {c.isActive ? 'Active' : 'Inactive'}
                  </span>
                  <div className="flex items-center gap-3">
                    <Link href={`/clients/${c._id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"><ExternalLink size={11}/>Details</Link>
                    <button onClick={() => selectClient(c)} className="text-xs text-brand font-medium hover:underline">Select</button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )
      }

      <Modal open={modal} onClose={close} title={editing ? 'Edit Client' : 'New Client'}
        footer={<><Button variant="outline" onClick={close}>Cancel</Button><Button onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button></>}>
        <div className="space-y-3">
          {formError && <div className="soft-alert border-red-500/25 bg-red-500/10 text-red-700 dark:text-red-300">{formError}</div>}
          <Input label="Business Name *" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Acme Corp" />
          <Input label="WABA ID *" value={form.wabaId} onChange={e => set('wabaId', e.target.value)} placeholder="102938475610293" />
          <Input label="Phone Number ID *" value={form.phoneNumberId} onChange={e => set('phoneNumberId', e.target.value)} placeholder="109283746501928" />
          <Input label={editing ? 'Access Token (leave blank to keep)' : 'Permanent Access Token *'} value={form.accessToken} onChange={e => set('accessToken', e.target.value)} type="password" placeholder="EAABsb…" />
          <Input label="Display Phone" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+919876543210" />
          <Input label="Industry" value={form.industry} onChange={e => set('industry', e.target.value)} placeholder="E-commerce" />
          <Input label="Timezone" value={form.timezone} onChange={e => set('timezone', e.target.value)} placeholder="Asia/Kolkata" />
        </div>
      </Modal>
    </AppShell>
  );
}
