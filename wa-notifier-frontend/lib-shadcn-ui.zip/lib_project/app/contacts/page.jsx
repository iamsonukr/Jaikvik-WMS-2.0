'use client';
import { useEffect, useState, useRef } from 'react';
import AppShell from '@/components/layout/AppShell';
import { Button, Card, Modal, Input, PageHeader, Badge, Empty, Spinner } from '@/components/ui';
import { useClient } from '@/hooks/useClient';
import api from '@/lib/api';
import { Plus, Upload, UserCircle, Search, Tag, Trash2 } from 'lucide-react';

const blank = { name: '', phone: '', tags: '' };

// Minimal CSV line parser that respects double-quoted fields containing commas
function parseCSVLine(line) {
  const result = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      result.push(cur); cur = '';
    } else {
      cur += ch;
    }
  }
  result.push(cur);
  return result.map(s => s.trim());
}

export default function ContactsPage() {
  const { activeClient } = useClient();
  const [contacts, setContacts] = useState([]);
  const [tags,     setTags]     = useState([]);
  const [tag,      setTag]      = useState('');
  const [search,   setSearch]   = useState('');
  const [modal,    setModal]    = useState(false);
  const [form,     setForm]     = useState(blank);
  const [loading,  setLoading]  = useState(false);
  const [saving,   setSaving]   = useState(false);
  const [importing,setImporting]= useState(false);
  const [formError,setFormError]= useState('');
  const [csvError, setCsvError] = useState('');
  const fileRef = useRef();

  const load = () => {
    if (!activeClient) return;
    setLoading(true);
    Promise.all([
      api.get(`/contacts?clientId=${activeClient._id}${tag ? `&tag=${tag}` : ''}`),
      api.get(`/contacts/tags?clientId=${activeClient._id}`),
    ]).then(([c, t]) => { setContacts(c.data); setTags(t.data); })
      .catch(() => { setContacts([]); setTags([]); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [activeClient, tag]);

  const save = async () => {
    setFormError('');
    const phone = form.phone.trim();
    if (!phone) { setFormError('Phone number is required'); return; }
    if (!/^\+?[1-9]\d{6,14}$/.test(phone.replace(/[\s-]/g, ''))) {
      setFormError('Enter a valid phone number in E.164 format, e.g. +919876543210');
      return;
    }
    setSaving(true);
    try {
      const dto = { ...form, phone, clientId: activeClient._id, tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [] };
      await api.post('/contacts', dto);
      setModal(false); setForm(blank); load();
    } catch (err) {
      setFormError(err?.response?.data?.message || 'Could not save contact. The phone number may already exist.');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id) => {
    if (!confirm('Delete contact?')) return;
    try {
      await api.delete(`/contacts/${id}`);
      setContacts(prev => prev.filter(c => c._id !== id));
    } catch {
      alert('Could not delete contact. Please try again.');
    }
  };

  const handleCSV = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setCsvError('');
    setImporting(true);
    try {
      const text = await file.text();
      const lines = text.split(/\r?\n/).filter(l => l.trim().length > 0);
      if (lines.length < 2) throw new Error('CSV must have a header row and at least one data row.');

      const headers = parseCSVLine(lines[0]).map(h => h.toLowerCase());
      const phoneIdx = headers.indexOf('phone');
      if (phoneIdx === -1) throw new Error('CSV must include a "phone" column.');

      const parsed = lines.slice(1).map(l => {
        const vals = parseCSVLine(l);
        const obj = {};
        headers.forEach((h, i) => { obj[h] = vals[i]; });
        return { phone: obj.phone, name: obj.name, tags: obj.tags ? obj.tags.split('|').map(t => t.trim()).filter(Boolean) : [] };
      }).filter(c => c.phone);

      if (parsed.length === 0) throw new Error('No valid rows with a phone number were found.');

      const { data } = await api.post('/contacts/bulk', { clientId: activeClient._id, contacts: parsed });
      load();
      if (data?.skipped) {
        setCsvError(`Imported ${parsed.length - data.skipped} contacts. Skipped ${data.skipped} row(s) with missing phone numbers.`);
      }
    } catch (err) {
      setCsvError(err?.response?.data?.message || err.message || 'Could not import CSV. Please check the file format.');
    } finally {
      setImporting(false);
      e.target.value = '';
    }
  };

  const filtered = contacts.filter(c =>
    !search || c.name?.toLowerCase().includes(search.toLowerCase()) || c.phone.includes(search)
  );

  return (
    <AppShell>
      <PageHeader
        title="Contacts"
        subtitle={`${contacts.length} contacts`}
        action={
          <div className="flex gap-2">
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleCSV} disabled={importing} />
            <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={importing || !activeClient}>
              <Upload size={15}/>{importing ? 'Importing…' : 'Import CSV'}
            </Button>
            <Button onClick={() => { setForm(blank); setFormError(''); setModal(true); }} disabled={!activeClient}><Plus size={15}/>Add Contact</Button>
          </div>
        }
      />

      {!activeClient && (
        <div className="soft-alert border-amber-500/25 bg-amber-500/10 text-amber-700 dark:text-amber-300 mb-5">
          Select a client first to manage contacts.
        </div>
      )}

      {csvError && (
        <div className="soft-alert border-amber-500/25 bg-amber-500/10 text-amber-700 dark:text-amber-300 mb-5">{csvError}</div>
      )}

      {/* Filters */}
      <div className="flex gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search name or phone…"
            className="w-full pl-8 pr-3 py-2 text-sm border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div className="flex gap-1 flex-wrap">
          <button onClick={() => setTag('')} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${!tag ? 'bg-brand text-white border-brand' : 'border-border text-muted-foreground hover:bg-accent hover:text-accent-foreground'}`}>All</button>
          {tags.map(t => (
            <button key={t} onClick={() => setTag(t)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${tag === t ? 'bg-brand text-white border-brand' : 'border-border text-muted-foreground hover:bg-accent hover:text-accent-foreground'}`}>{t}</button>
          ))}
        </div>
      </div>

      {loading && <div className="flex justify-center py-20"><Spinner size={32} /></div>}

      {!loading && (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[var(--dark-border)]">
                  {['Name','Phone','Tags','Opted Out',''].map(h => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-medium text-[var(--muted-text)]">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--dark-border)]">
                {filtered.length === 0 && (
                  <tr><td colSpan={5} className="text-center py-12 text-[var(--muted-text)]">No contacts found</td></tr>
                )}
                {filtered.map(c => (
                  <tr key={c._id} className="table-row-hover">
                    <td className="px-4 py-3 font-medium">{c.name || '—'}</td>
                    <td className="px-4 py-3 text-[var(--muted-text)]">{c.phone}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1 flex-wrap">
                        {c.tags?.map(t => <Badge key={t} label={t} color="blue" />)}
                      </div>
                    </td>
                    <td className="px-4 py-3">{c.isOptedOut ? <Badge label="Opted out" color="red" /> : <Badge label="Active" color="green" />}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => remove(c._id)} className="text-muted-foreground hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title="Add Contact"
        footer={<><Button variant="outline" onClick={() => setModal(false)}>Cancel</Button><Button onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button></>}>
        <div className="space-y-3">
          {formError && <div className="bg-red-50 border border-red-200 text-red-600 text-sm px-3 py-2 rounded-lg">{formError}</div>}
          <Input label="Phone (E.164) *" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} placeholder="+919876543210" />
          <Input label="Name" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="John Doe" />
          <Input label="Tags (comma separated)" value={form.tags} onChange={e => setForm(p => ({ ...p, tags: e.target.value }))} placeholder="vip, newsletter" />
        </div>
      </Modal>
    </AppShell>
  );
}
