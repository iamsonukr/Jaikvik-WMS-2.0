'use client';
import { useEffect, useState } from 'react';
import AppShell from '@/components/layout/AppShell';
import { StatCard, Card, CardHeader, StatusBadge, Spinner, PageHeader } from '@/components/ui';
import { useClient } from '@/hooks/useClient';
import api from '@/lib/api';
import { Users, Send, CheckCheck, Eye, AlertCircle, Megaphone } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function DashboardPage() {
  const { activeClient } = useClient();
  const [stats,  setStats]  = useState(null);
  const [daily,  setDaily]  = useState([]);
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!activeClient) {
      setStats(null); setDaily([]); setRecent([]);
      return;
    }
    const cid = activeClient._id;
    setLoading(true);
    Promise.all([
      api.get(`/analytics/overview?clientId=${cid}`),
      api.get(`/analytics/daily?clientId=${cid}&days=14`),
      api.get(`/broadcasts?clientId=${cid}`),
    ]).then(([s, d, b]) => {
      setStats(s.data);
      setDaily(d.data);
      setRecent(b.data.slice(0, 5));
    }).catch(() => {
      setStats(null); setDaily([]); setRecent([]);
    }).finally(() => setLoading(false));
  }, [activeClient]);

  return (
    <AppShell>
      <PageHeader
        title="Dashboard"
        subtitle={activeClient ? `Overview for ${activeClient.name}` : 'Select a client to begin'}
      />

      {!activeClient && (
        <div className="soft-alert border-amber-500/25 bg-amber-500/10 text-amber-700 dark:text-amber-300">
          No client selected. Add a client from the Clients page to get started.
        </div>
      )}

      {loading && <div className="flex justify-center py-20"><Spinner size={32} /></div>}

      {stats && !loading && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
            <StatCard label="Contacts"  value={stats.totalContacts}  icon={Users}      color="#25D366" />
            <StatCard label="Campaigns" value={stats.totalBroadcasts} icon={Megaphone} color="#3b82f6" />
            <StatCard label="Sent"      value={stats.totalSent}      icon={Send}        color="#6366f1" />
            <StatCard label="Delivered" value={stats.totalDelivered} icon={CheckCheck}  color="#22c55e" />
            <StatCard label="Read"      value={stats.totalRead}      icon={Eye}         color="#f59e0b" />
            <StatCard label="Failed"    value={stats.totalFailed}    icon={AlertCircle} color="#ef4444" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Chart */}
            <Card className="lg:col-span-2">
              <CardHeader title="Messages (last 14 days)" />
              <div className="p-4 h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={daily}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="_id" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip />
                    <Line type="monotone" dataKey="sent"      stroke="#6366f1" strokeWidth={2} dot={false} name="Sent" />
                    <Line type="monotone" dataKey="delivered" stroke="#22c55e" strokeWidth={2} dot={false} name="Delivered" />
                    <Line type="monotone" dataKey="read"      stroke="#f59e0b" strokeWidth={2} dot={false} name="Read" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>

            {/* Recent broadcasts */}
            <Card>
              <CardHeader title="Recent Campaigns" />
              <div className="divide-y divide-[var(--dark-border)]">
                {recent.length === 0 && <p className="text-sm text-[var(--muted-text)] p-4">No campaigns yet.</p>}
                {recent.map(b => (
                  <div key={b._id} className="px-4 py-3 flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{b.name}</p>
                      <p className="text-xs text-[var(--muted-text)]">{b.sentCount} sent</p>
                    </div>
                    <StatusBadge status={b.status} />
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </>
      )}
    </AppShell>
  );
}
