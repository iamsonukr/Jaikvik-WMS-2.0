'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, Users, UserCircle, FileText, Megaphone,
  Inbox, Bot, BarChart2, Settings, MessageCircle, LogOut, ChevronDown, X, Check,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { useClient } from '@/hooks/useClient';
import { useState } from 'react';
import { Avatar, AvatarFallback } from '@/components/ui';

const nav = [
  { href: '/dashboard',   label: 'Dashboard',   icon: LayoutDashboard },
  { href: '/broadcasts',  label: 'Broadcasts',  icon: Megaphone },
  { href: '/inbox',       label: 'Inbox',       icon: Inbox },
  { href: '/contacts',    label: 'Contacts',    icon: UserCircle },
  { href: '/templates',   label: 'Templates',   icon: FileText },
  { href: '/chatbot',     label: 'Chatbot',     icon: Bot },
  { href: '/analytics',   label: 'Analytics',   icon: BarChart2 },
  { href: '/clients',     label: 'Clients',     icon: Users },
  { href: '/settings',    label: 'Settings',    icon: Settings },
];

export default function Sidebar({ open = false, onClose = () => {} }) {
  const pathname               = usePathname();
  const { user, logout }       = useAuth();
  const { clients, activeClient, selectClient } = useClient();
  const [clientOpen, setClientOpen] = useState(false);

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-white/10 bg-[#07111f] text-slate-300 shadow-2xl transition-transform duration-200 lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}
    >

      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-white/10">
        <div className="relative w-9 h-9 shrink-0 rounded-xl flex items-center justify-center bg-brand-gradient shadow-lg shadow-brand/25">
          <MessageCircle size={18} color="#fff" strokeWidth={2.25} />
          <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-[#07111f]" />
        </div>
        <div className="min-w-0">
          <span className="block font-bold text-white text-base tracking-tight">WA Notifier</span>
          <span className="block text-[11px] text-slate-500">Business messaging</span>
        </div>
        <button
          type="button"
          aria-label="Close navigation"
          onClick={onClose}
          className="ml-auto inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-white/10 hover:text-white lg:hidden"
        >
          <X size={16} />
        </button>
      </div>

      {/* Client switcher */}
      {clients.length > 0 && (
        <div className="px-3 py-3 border-b border-white/10 relative">
          <button
            onClick={() => setClientOpen(p => !p)}
            className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-sm bg-white/[0.04] hover:bg-white/10 transition-colors border border-white/5"
          >
            <span className="flex items-center gap-2 min-w-0">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-brand-gradient text-[10px] font-bold text-white">
                {activeClient?.name?.[0]?.toUpperCase() || '?'}
              </span>
              <span className="truncate font-medium text-white">
                {activeClient?.name || 'Select client'}
              </span>
            </span>
            <ChevronDown size={14} className={`shrink-0 transition-transform duration-200 ${clientOpen ? 'rotate-180' : ''}`} />
          </button>
          {clientOpen && (
            <div className="absolute left-3 right-3 top-full mt-1.5 z-10 rounded-lg overflow-hidden border border-white/10 bg-[#0b1524] shadow-2xl animate-fade-in max-h-64 overflow-y-auto">
              {clients.map(c => (
                <button key={c._id}
                  onClick={() => { selectClient(c); setClientOpen(false); }}
                  className={`w-full flex items-center justify-between gap-2 text-left px-3 py-2.5 text-sm transition-colors
                    ${activeClient?._id === c._id ? 'bg-brand-gradient text-white' : 'hover:bg-white/10 text-slate-300'}`}>
                  <span className="truncate">{c.name}</span>
                  {activeClient?._id === c._id && <Check size={14} className="shrink-0" />}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
        {nav.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(href + '/');
          return (
            <Link key={href} href={href}
              onClick={onClose}
              className={`group relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150
                ${active ? 'bg-brand-gradient text-white shadow-lg shadow-brand/20' : 'text-slate-400 hover:bg-white/[0.07] hover:text-white'}`}>
              <Icon size={17} className={active ? '' : 'transition-transform duration-150 group-hover:scale-110'} />
              {label}
              {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-white/80" />}
            </Link>
          );
        })}
      </nav>

      {/* User */}
      <div className="px-3 py-3 border-t border-white/10">
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/[0.04] transition-colors">
          <Avatar className="h-8 w-8 ring-2 ring-white/10">
            <AvatarFallback className="text-[11px]">{user?.name?.[0]?.toUpperCase() || 'U'}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.name || 'User'}</p>
            <p className="text-xs text-slate-500 truncate">{user?.email}</p>
          </div>
          <button onClick={logout} className="text-slate-400 hover:text-white transition-colors" aria-label="Log out">
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
}
