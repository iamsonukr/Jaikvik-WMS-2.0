'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import api from '@/lib/api';
import { useAuth } from '@/lib/auth-context';

const ClientCtx = createContext(null);

export function ClientProvider({ children }) {
  const { user } = useAuth();
  const [clients, setClients]           = useState([]);
  const [activeClient, setActiveClient] = useState(null);

  useEffect(() => {
    if (!user) {
      // Logged out (or not yet authenticated) — clear stale state from a previous session
      setClients([]);
      setActiveClient(null);
      return;
    }
    api.get('/clients').then(r => {
      setClients(r.data);
      const stored = localStorage.getItem('wa_active_client');
      const found  = r.data.find(c => c._id === stored) || r.data[0];
      if (found) setActiveClient(found);
    }).catch(() => {});
  }, [user]);

  const selectClient = (client) => {
    setActiveClient(client);
    localStorage.setItem('wa_active_client', client._id);
  };

  return (
    <ClientCtx.Provider value={{ clients, activeClient, selectClient, setClients }}>
      {children}
    </ClientCtx.Provider>
  );
}

export const useClient = () => useContext(ClientCtx);
